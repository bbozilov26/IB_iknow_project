﻿using System.Collections.Generic;

namespace IknowFinal.Models
{
    public class StudentViewModel
    {
        
        public List<StudentSubjectViewModel> Subjects { get; set; } = new List<StudentSubjectViewModel>();
    }
}
