﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;
using System.Linq;
using System.Threading.Tasks;

namespace IknowFinal.Models
{
    public class StudentSubject
    {
        public int Id { get; set; }

        [Range(5, 10, ErrorMessage = "Value for {0} must be between {1} and {2}.")]
        public int? Grade { get; set; }

        public int StudentId { get; set; }

        public Student Student { get; set; }

        public int SubjectId { get; set; }

        public Subject Subject { get; set; }

        public int? ProfessorId { get; set; }

        public Professor Professor { get; set; }

        




    }
}
