﻿using System.ComponentModel.DataAnnotations;

namespace IknowFinal.Models
{
    public class StudentSubjectViewModel
    {
        public string Name { get; set; }
        [Range(5,10)]
        public int? Grade { get; set; }
    }
}
