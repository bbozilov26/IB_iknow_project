﻿using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Configuration;

namespace IknowFinal.Models
{
    public class ProfessorViewModel
    {
        public string LoggedInProfessorId { get; set; }
        public string SelectedSubjectId { get; set; }
        public List<Subject> ProfessorSubjects { get; set; } = new List<Subject>();
        public List<StudentSubjectViewModel> SubjectStudents { get; set; } = new List<StudentSubjectViewModel>();
        public List<Student> StudentsForAddingGrade { get; set; } = new List<Student>();
        public string SelectedStudentsForAddingGradeId { get; set; }

        [Range(5, 10, ErrorMessage = "Value for {0} must be between {1} and {2}.")]
        public string SelectedStudentsGradeToSave { get; set; }
    }
}
