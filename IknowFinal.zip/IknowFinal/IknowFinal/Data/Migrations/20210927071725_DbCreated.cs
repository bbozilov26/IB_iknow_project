﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace IknowFinal.Data.Migrations
{
    public partial class DbCreated : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
